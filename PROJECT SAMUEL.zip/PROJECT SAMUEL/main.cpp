#include <iostream>
#include <string>
#include <map>
#include <cstdlib>
#include <ctime>
#include <sstream>
#include <iomanip>
#include <openssl/sha.h>

class PasswordManager {
private:
    std::map<std::string, std::string> passwords;

public:
    void addPassword(const std::string& website, const std::string& password) {
        std::string hashedPassword = hashPassword(password);
        passwords[website] = hashedPassword;
    }

    bool getPassword(const std::string& website, std::string& password) {
        auto it = passwords.find(website);
        if (it != passwords.end()) {
            password = it->second;
            return true;
        }
        return false;
    }

    void updatePassword(const std::string& website, const std::string& newPassword) {
        std::string hashedPassword = hashPassword(newPassword);
        passwords[website] = hashedPassword;
    }

    void deletePassword(const std::string& website) {
        passwords.erase(website);
    }

private:
    std::string hashPassword(const std::string& password) {
        unsigned char hashed[SHA256_DIGEST_LENGTH];
        SHA256((const unsigned char*)password.c_str(), password.length(), hashed);

        std::stringstream ss;
        for(int i = 0; i < SHA256_DIGEST_LENGTH; ++i)
            ss << std::hex << std::setw(2) << std::setfill('0') << (int)hashed[i];
        
        return ss.str();
    }
};

std::string generateRandomPassword(int length) {
    const std::string chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890!@#$%^&*()_+";

    std::string password;
    int charsLength = chars.length();

    std::srand(std::time(nullptr));
    for (int i = 0; i < length; ++i) {
        int randomIndex = std::rand() % charsLength;
        password += chars[randomIndex];
    }

    return password;
}

int main() {
    PasswordManager manager;

    while (true) {
        std::cout << "1. Add Password\n2. Get Password\n3. Update Password\n4. Delete Password\n5. Generate Random Password\n6. Exit\n";
        int choice;
        std::cin >> choice;

        if (choice == 1) {
            std::string website, password;
            std::cout << "Enter website: ";
            std::cin >> website;
            std::cout << "Enter password: ";
            std::cin >> password;
            manager.addPassword(website, password);
            std::cout << "Password added successfully.\n";
        } else if (choice == 2) {
            std::string website, password;
            std::cout << "Enter website: ";
            std::cin >> website;
            if (manager.getPassword(website, password)) {
                std::cout << "Password for " << website << ": " << password << "\n";
            } else {
                std::cout << "Password not found.\n";
            }
        } else if (choice == 3) {
            std::string website, newPassword;
            std::cout << "Enter website: ";
            std::cin >> website;
            std::cout << "Enter new password: ";
            std::cin >> newPassword;
            manager.updatePassword(website, newPassword);
            std::cout << "Password updated successfully.\n";
        } else if (choice == 4) {
            std::string website;
            std::cout << "Enter website: ";
            std::cin >> website;
            manager.deletePassword(website);
            std::cout << "Password deleted successfully.\n";
        } else if (choice == 5) {
            int length;
            std::cout << "Enter password length: ";
            std::cin >> length;
            std::string randomPassword = generateRandomPassword(length);
            std::cout << "Generated random password: " << randomPassword << "\n";
        } else if (choice == 6) {
            break;
        } else {
            std::cout << "Invalid choice. Please try again.\n";
        }
    }

    return 0;
}
